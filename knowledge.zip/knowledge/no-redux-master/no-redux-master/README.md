# Replacing Redux with hooks and context
This is the final code for a tutorial I wrote [here on Medium](https://medium.com/@richbray/replacing-redux-with-react-hooks-and-context-part-1-11b72ffdb533).


## Install
To install this locally make sure you have NodeJS on your machine.
Then install the dependencies with:
```
$ npm i
```

And run the applicaiton with:
```
$ npm start
```


## Show some love?

If you've found this project useful and would like to support me there are several ways you could do so.
- Support me on [Patreon](https://www.patreon.com/richardobray)
- Subscribe to my videos on [Youtube](https://www.youtube.com/channel/UC6matv_t6jTc17oJdPkjUVQ)
- Follow me on [Twitter](https://twitter.com/Ceiga?lang=en-gb)
